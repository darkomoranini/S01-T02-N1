
public class App {

	public static void main(String[] Args) {
		
		Venta venta=new Venta();
		
		Producto p1=new Producto("zapatos", 50);
		Producto p2=new Producto("abrigo", 70);
		Producto p3=new Producto("sombrero", 20);
		
		venta.addProducto(p1);
		venta.addProducto(p2);
		venta.addProducto(p3);
		
		try {
		System.out.println(venta.calculaPrecioTotal());
		}catch(VentaVaciaException e){
			System.out.println("No hay productos en la lista");
		}	
		
		try {
			venta.buscarProducto("zapatos");
		}catch (ArrayIndexOutOfBoundsException i) {
			System.out.println("Ha surgido un error en el sistema");
		}
	}
}
