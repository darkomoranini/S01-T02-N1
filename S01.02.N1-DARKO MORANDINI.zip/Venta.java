import java.util.ArrayList;

public class Venta {
	private ArrayList<Producto>listaProductos;
	private int precioTotal;
	
	public Venta() {
		listaProductos=new ArrayList<Producto>();
		precioTotal=0;
	}
	public ArrayList<Producto>getListaProductos(){
		return listaProductos;
	}
	public int getPrecioTotal() {
		return precioTotal;
	}
	public int calculaPrecioTotal() throws VentaVaciaException {
		
		if(listaProductos.size()==0) {
			throw new VentaVaciaException();
		}
		for(int i=0;i<listaProductos.size(); i++) {
			precioTotal+=listaProductos.get(i).getPrecio();	
		}
		return precioTotal;
	}
	public void addProducto(Producto producto) {
		listaProductos.add(producto);
	}
	public int buscarProducto(String nombre) throws ArrayIndexOutOfBoundsException {
		
		int contador=0;
		
		if(contador>listaProductos.size()) {
			throw new ArrayIndexOutOfBoundsException();
		}
		while(!nombre.equalsIgnoreCase(listaProductos.get(contador).getNombre())&&contador<listaProductos.size()) {	
			contador ++;
		}
		if(contador>listaProductos.size()) {
			contador = -1;
		}
		return contador;
	}
}
