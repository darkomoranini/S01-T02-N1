
public class VentaVaciaException extends Exception{

	public VentaVaciaException() {
	
	}
	public VentaVaciaException(String mensajeError) {
	
		super(mensajeError);	
	}
}
